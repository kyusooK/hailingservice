# Please check before using Github action.

## First, change the folder name 
```
github/workflows -> .github/workflows
```
## Second, change the configuration of git-action.

1. Check Setting of your repository 
<img width="931" alt="setting1" src="https://github.com/sooheon45/topping-github-action/assets/54785805/4007c96b-1244-43ad-bf5c-042a114a0ba1">

2. Setting > Actions > Genernal > Workflow permissions 
<img width="333" alt="setting2" src="https://github.com/sooheon45/topping-github-action/assets/54785805/059d6d61-ee9e-41ec-8e08-1021031a18fe">

3. Select of "Read and write Permissions."
<img width="903" alt="setting3" src="https://github.com/sooheon45/topping-github-action/assets/54785805/fe562497-e860-4d8b-9d5a-f189ef3dce8d">
